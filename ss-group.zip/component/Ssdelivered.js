import React from 'react'
import Slider from "react-slick";
import Image from 'next/image';

const Ssdelivered = () => {
    var settings = {
        dots: false,
        infinite: false,
        speed:500,
        slidesToShow: 1.1,
        slidesToScroll: 1,
        autoplaySpeed: 5000,
        autoplay: false,
        responsive: [
          {
            breakpoint: 990, 
            settings: {
              slidesToShow: 1,
              arrows: false,
            },
          },
        ]
      };
  return (
    <>
         <section>
 <div className="container">
        
 <div className="row">
          <div className="sscompleted col-12 float-start">
        <div className='col-12 float-start text-center title' data-aos="fade-left" data-aos-easing="ease-in" data-aos-offset="50" data-aos-duration="800" data-aos-once='true'>
            <span className="colorborder position-relative"><em></em></span>
              <h3>Completed</h3>
            </div>
            
            <div className="col-lg-11 m-auto col-12 image-effect-section">
            <Slider {...settings} className="col-12 float-start">
          <div>
           <div className="completeslide">
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
               <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/173061120594488984.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/387040490562586781.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/67675341THE%20HIBISCUS%20PENTHOUSE.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   </div>
           <div className="completeslide">
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   </div>
          </div>
          <div>
           <div className="completeslide">
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   </div>
           <div className="completeslide">
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   <div className="completeproject">
            <div className="completeimg">
              <Image src="https://www.ssgroup-india.com/images/1423918489spro07.jpg" alt="Project Image" width={655} height={597} />
            </div>
            <div className="completedetails">
            <div className="mantainde">
               <h4>Project Name</h4>
                <p>Project Location</p>
               </div>
            </div>
           </div>
		   </div>
          </div>
        </Slider>
            </div>
            </div>
      </div>
            </div>
        </section>
    </>
  )
}

export default Ssdelivered